# com.dynatrace.custom.snmp.cisco-firepower

**Latest version:** 0.2.3
This extension is built using the Dynatrace Extension 2.0 Framework.
This means it will benefit of additional assets that can help you browse through the data.

## Topology

This extension will create the following types of entities:
* Cisco Firepower Firewall Device (snmp:cisco_firepower)

## Metrics

This extension will collect the following metrics:
* Split by Cisco Firepower Firewall Device:
  * User CPU time (`snmp.cisco.firepower.cpu.user.count`)
    The number of 'ticks' (typically 1/100s) spent processing user-level code. (as MilliSecond)
  * System CPU time (`snmp.cisco.firepower.cpu.system.count`)
    The number of 'ticks' (typically 1/100s) spent processing system-level code. (as MilliSecond)
  * Idle CPU time (`snmp.cisco.firepower.cpu.idle.count`)
    The number of 'ticks' (typically 1/100s) spent idle. (as MilliSecond)
  * RAM total (`snmp.cisco.firepower.memory.total`)
    Total Real/Physical Memory Size on the host (as KiloByte)
  * RAM available (`snmp.cisco.firepower.memory.available`)
    The amount of real/physical memory currently unused or available. (as KiloByte)
  * RAM free (`snmp.cisco.firepower.memory.free`)
    Total Available Memory on the host (as KiloByte)
* Split by :
  * CPU User percentage (`func:snmp.cisco.firepower.cpu.percentage.user`)
    Percentage of user CPU time (as Percent)
  * CPU System percentage (`func:snmp.cisco.firepower.cpu.percentage.system`)
    Percentage of system CPU time (as Percent)
  * CPU Idle percentage (`func:snmp.cisco.firepower.cpu.percentage.idle`)
    Percentage of idle CPU time (as Percent)
  * Memory used percent (`func:cisco.firepower.memory.used.percent`)
    undefined (as Percent)
  * Memory used (`func:cisco.firepower.memory.used`)
    undefined (as KiloByte)

## Dashboards

This extension is packaged with 1 dashboards which should serve as a starting point for data analysis.
You can find these by opening the Dashboards menu and searching for:

* Cisco Firepower Extension Overview

# Configuration

## Feature sets

Feature sets can be used to opt in and out of metric data collection.
This extension groups together metrics within the following feature sets:

* default
* poc-tested
  * snmp.cisco.firepower.cpu.user.count
  * snmp.cisco.firepower.cpu.system.count
  * snmp.cisco.firepower.cpu.idle.count
  * snmp.cisco.firepower.memory.total
  * snmp.cisco.firepower.memory.available
  * snmp.cisco.firepower.memory.free
  * poc.ibm_mq.disk.available

