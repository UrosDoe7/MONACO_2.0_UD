# SNMP Cisco Firepower Extension

## Changelog

### v1.0.1

- Adds `snmp.cisco.asa.cras.num_sessions` metric and related UA chart