The extension package contains:

- SNMP data source configuration for metric ingestion
- Topology definitions for Cisco Firepower devices.
- Dashboards offering monitoring overviews
- Unified Analysis pages for each created entity

The extension is built on top of the [SNMP data source](https://docs.dynatrace.com/docs/shortlink/snmp-extension) that is part of Dynatrace's [Extensions 2.0](https://docs.dynatrace.com/docs/shortlink/extensions20) framework. 