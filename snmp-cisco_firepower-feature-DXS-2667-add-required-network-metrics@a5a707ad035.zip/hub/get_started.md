Activate the extension in your environment web-UI using the [Dynatrace Hub](https://www.dynatrace.com/hub). Simply provide the necessary device configuration, and Dynatrace will automatically deploy the extension and begin monitoring.

Read more in our [SNMP extension documentation](https://docs.dynatrace.com/docs/extend-dynatrace/extend-metrics/ingestion-methods/snmp).