from Helper import *
from datetime import date
from datetime import datetime
import sys
sys.path.insert(1, "../DT_API")
from Call_dt import *

def get_metrics_keys(dt_api):
    results = {"totalCount": 0, "metrics": []}
    metrics = []
    query_params = {
        "pageSize": 500,
        "fields": "+created,+lastWritten,+latency"
    }
    while True:
        r = dt_api.get_metrics(query_params)
        metrics += r["metrics"]
        if "nextPageKey" in r:
            if r["nextPageKey"] != "" and r["nextPageKey"] != None:
                query_params = {"nextPageKey": r["nextPageKey"]}
            else:
                break
        else:
            break
    results["totalCount"] = r["totalCount"]
    results["metrics"] = metrics

    # To make it easy: convert the timestamp milli to datetime, and create a new field
    for m in results["metrics"]:
        m["created_datetime"] = ""
        if m["created"] != None:
            m["created_datetime"] = str(datetime.fromtimestamp(m["created"] / 1000.0))
        m["lastWritten_datetime"] = ""
        if m["lastWritten"] != None:
            m["lastWritten_datetime"] = str(datetime.fromtimestamp(m["lastWritten"] / 1000.0))

    return results


if __name__ == "__main__":
    args = initialize_program(__file__, "Manage Metrics")
    today = date.today()
    # Tests DT Calls
    tenant_id = args["tenant_id"]
    is_managed = args["is_managed"]
    print(is_managed)
    dt_api = Call_dt(tenant_id, is_managed)

    if args["test"]:
        print("Test mode")  
        metrics_list = get_metrics_keys(dt_api)      
        #print(json.dumps(metrics_list))
        create_json_file(metrics_list, REPORTS_DIR + "/" + str(today) + "_" + tenant_id + "_metrics-list.json")
    else:
        print("Regular mode")