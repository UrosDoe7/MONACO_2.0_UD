import argparse
import json
import yaml
import os
import logging

SCRIPT_DIR = os.path.dirname(__file__)
OUTPUT_DIR = SCRIPT_DIR + "/output"
REPORTS_DIR = OUTPUT_DIR + "/reports"
LOGS_DIR = OUTPUT_DIR + "/logs"
SRC_DIR = SCRIPT_DIR + "/src"
PROJECTS_DIR = SRC_DIR + "/projects"
logging.basicConfig(filename=LOGS_DIR + "/executions.log", level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

def initialize_program(calling_script_file, prg_description):
    parser = argparse.ArgumentParser(description=prg_description)
    parser.add_argument("--test", help="test mode", required=False, action="store_true")
    parser.add_argument("--tenant-id", help="tenant id", required=True)
    parser.add_argument("--is-managed", help="use this parameter if dealing with managed environment", required=False, action="store_true")
    args = parser.parse_args()
    return vars(args)

def read_json(filepath):
    f = open(filepath)
    data = json.load(f)
    f.close()
    return data

def read_yaml(filepath):
    f = open(filepath)
    data = yaml.safe_load(f)
    f.close()
    return data 

def path_exists(filepath):
    return os.path.exists(os.path.dirname(filepath))

def create_json_file(json_data, json_file_path):
    if not path_exists(json_file_path):
        os.makedirs(os.path.dirname(json_file_path))
    with open(json_file_path, 'w') as outfile:
        json.dump(json_data, outfile)

def create_yaml_file(dict_data, yaml_file_path):
    if not path_exists(yaml_file_path):
        os.makedirs(os.path.dirname(yaml_file_path))
    with open(yaml_file_path, 'w', encoding="utf-8") as outfile:
        yaml.dump(dict_data, outfile, allow_unicode=True)