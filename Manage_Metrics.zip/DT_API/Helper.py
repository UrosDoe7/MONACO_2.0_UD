import json
import yaml
import os

def read_json(filepath):
    f = open(filepath)
    data = json.load(f)
    f.close()
    return data

def read_yaml(filepath):
    f = open(filepath)
    data = yaml.safe_load(f)
    f.close()
    return data 

def path_exists(filepath):
    return os.path.exists(os.path.dirname(filepath))

def create_json_file(json_data, json_file_path):
    if not path_exists(json_file_path):
        os.makedirs(os.path.dirname(json_file_path))
    with open(json_file_path, 'w') as outfile:
        json.dump(json_data, outfile)

def create_yaml_file(dict_data, yaml_file_path):
    if not path_exists(yaml_file_path):
        os.makedirs(os.path.dirname(yaml_file_path))
    with open(yaml_file_path, 'w', encoding="utf-8") as outfile:
        yaml.dump(dict_data, outfile, allow_unicode=True)