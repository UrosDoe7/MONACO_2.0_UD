import requests
import json
import logging
import time
from Helper import *
requests.packages.urllib3.disable_warnings()

SCRIPT_DIR = os.path.dirname(__file__)
CONFIG_DIR = SCRIPT_DIR + "/config"

class DynatraceException(Exception):
    def __init__(self, message):
        self.message = message

class Call_dt:
    _protocol = "https"
    _url = ""
    _number_retry = 10
    _wait_call_api = 10
    _token = None

    def __init__(self, tenant_id, is_managed=False):
        token = self.get_token(tenant_id)
        domain = self.get_domain(tenant_id)
        if is_managed: 
            self._url = self._protocol + "://" + domain + "/e/" + tenant_id
        else:
            self._url = self._protocol + "://" + tenant_id + "." + domain
        self._token = token

    def call_dt_api(self, method="get", endpoint=None, data=None, params=None, token=None, headers=None):
        json_results = None
        if headers == None:
            headers = {'Authorization': 'Api-Token ' + self._token, 'content-type': 'application/json'}
        url = self._url + endpoint
        print(method + " " + url)

        count_try = 0
        track_429 = False
        while count_try < self._number_retry:
            response = None
            track_429 = False
            if method == "get":
                response = requests.get(url, params=params, headers=headers, verify=False)
            elif method == "post":
                response = requests.post(url, params=params, data=data, headers=headers, verify=False)
            elif method == "put":
                response = requests.put(url, data=data, headers=headers, verify=False)
            elif method == "delete":
                response = requests.delete(url, headers=headers, verify=False)
            else:
                break

            print(response.status_code)
            # if len(response.text) > 0:
            #     if "<html>" in response.text:
            #         return response
            #     else:
            #         json_result = json.loads(response.text)
            #         return json_result
            
            # if type(json_result) is dict:
            #     if "error" in json_result.keys():
            #         if json_result["error"]["code"] == 429:
            #             time.sleep(self._wait_call_api)
            #             count_try += 1
            #             track_429 = True
            #         else:
            #             print("error when calling Dynatrace: {}, {}".format(json_result["error"]["code"], json_result["error"]["message"]))
            #     else:
            #         break
            # else:
            #     break
            if response.status_code == 429:
                time.sleep(self._wait_call_api)
                count_try += 1
                track_429 = True
            else:
                if response.text == "":
                    return None
                else:
                    return json.loads(response.text)
            
            if track_429 and count_try >= self._number_retry:
                raise DynatraceException("Max retries calling DT exceeded")

    def get_token(self, tenant_id):
        tokens = read_json(CONFIG_DIR + "/tokens/tokens.json")
        result = None
        if tenant_id in tokens:
            result = tokens[tenant_id]
        return result

    def get_domain(self, tenant_id):
        domains = read_json(CONFIG_DIR + "/tokens/domains.json")
        result = None
        if tenant_id in domains:
            result = domains[tenant_id]
        return result

    # APIs
    def get_monitored_entities(self, query_params):
        endpoint = "/api/v2/entities"
        return self.call_dt_api(method="get", endpoint=endpoint, params=query_params)
    
    def post_logs_ingest(self, payload):
        endpoint = "/api/v2/logs/ingest"
        return self.call_dt_api(method="post", endpoint=endpoint, data=json.dumps(payload))
    
    def get_metrics(self, query_params):
        endpoint = "/api/v2/metrics"
        return self.call_dt_api(method="get", endpoint=endpoint, params=query_params)